(cd src/webview/ts && npm install && npm run build)
(npm install && npm run compile)
./node_modules/vsce/out/vsce package