(cd src/nim/ && nim doc --project src/server.nim)
firefox src/nim/src/htmldocs/server.html &