# Instructions

This file explains how to build, install and run the Visual Studio Code extension on lab machines.

For instructions on how to use this software please refer to the user guide appended to the
report.

## Warning
Please make sure output to be visualised is stored in scratch space and NOT on the networked file system.  

# Build Instructions

## Prerequisites

### Already installed in the lab

* Visual Studio Code 
https://code.visualstudio.com/

* Npm
https://www.npmjs.com/

* Node
https://nodejs.org/en/

* Sqlite3
https://www.sqlite.org/download.html

### Must be installed for lab machines

* Conjure 
```
https://constraintmodelling.org/conjure/
```

* Savile Row
```
https://constraintmodelling.org/savilerow/
```
Please remember to add all executables to your $PATH

## Build and install minion
```
cd minion
mkdir build 
cd build 
../configure.py 
make
```
Now add ./minion to your $PATH.

Move back to the root directory
```
cd ../..
```

## Install Nim

Follow the instructions provided when executing this script.
```
curl https://nim-lang.org/choosenim/init.sh -sSf | sh

```
Remember to add the executable to your $PATH

## Build the extension
```
(cd extension && ./buildExtension.sh)
```
# Install the extension
```
code --install-extension extension/conjure-0.0.1.vsix
```
The extension is now installed.

## Installation Alternative
If you do not want to install the extension you can instead run a developer instance of vscode with the extension activated.
1. First open the source directory in Visual Studio Code
```
code ./extension
```
2. Press "F5" to start an instance of vscode with the extension installed. (This will not affect your global visual studio code installation)

# Running the extension
For the visualisation to work the server must be started.

Open a terminal and start the server:
```
(cd extension && ./runServer.sh)
```
Now start visual studio code in the problem to visualise
```
code ./demo
```

Please consult the user guide appended to the report for usage instructions.

# Uninstalling
```
code --uninstall-extension extension/conjure-0.0.1.vsix
```
The extension is now uninstalled.

# Running tests
## Run the server tests
```
(cd extension && ./runServerTests.sh)
```

## Run the webview tests
```
(cd extension && ./runWebviewTests.sh)
```

# Building documentation

## Server Documentation
```
(cd extension && ./genServerDocs.sh)
```

Documentation for the server can now be found at:
```
./extension/src/nim/src/htmldocs/server.html
```
Please note that only exported members of a module are included in the documentation.

## Webview Documentation
```
(cd extension && ./genWebviewDocs.sh)
```
Documentation for the server can now be found at:
```
./extension/src/webview/ts/docs
```

## Extension Documentation
```
(cd extension && ./genExtensionDocs.sh)
```
Documentation for the server can now be found at:
```
./extension/src/webview/ts/docs
```








