#include "minion.h"
#include "search_dump.hpp"
#include <sqlite3.h>

class DumpTreeSQL : public SearchDumper {
  DumpTreeSQL(const DumpTreeSQL&);

  sqlite3* db;
  sqlite3_stmt* insertNodeStmt;
  sqlite3_stmt* insertDomainStmt;

  // Keeps track of the parent ID
  std::vector<long long> parent_stack;
  // Keeps track of whether the current node is a left or right child
  std::vector<bool> isLeftStack;
  // Maps a domain name to a list of its indexes
  std::unordered_map<string, vector<int>> indexMap;
  // The ID of the parent of the last outputted node.
  long currentParent = -1;

public:
  DumpTreeSQL(string fileName) {
    makeDB(fileName);
    parent_stack.push_back(0);
    isLeftStack.push_back(true);
  }

// Called before search is started
  void initial_variables(const std::vector<AnyVarRef>& vars) {
    writeNodeToDb(0, -1, true, "", -1, false);
    writeDomainsToDb(0, vars);
  }

// Called when a node is generated
  void output_node(long long nodeCount, const std::vector<AnyVarRef>& vars, bool isSolution) {
    if (nodeCount > 0){
      writeDomainsToDb(nodeCount, vars);
    }
    if(parent_stack.size() > 0) {
      currentParent = parent_stack.back();

      if(isSolution) {
        writeNodeToDb(nodeCount, parent_stack.back(), isLeftStack.back(), "", -1, true);
      }
    }
  }

// Called when Minion back tracks
  void backtrack() {
    parent_stack.pop_back();
  }

// Called whenever Minion branches
  void branch(long long nodeCount, const std::string& varname, DomainInt val, bool isLeft) {
    if(isLeft) {
      writeNodeToDb(nodeCount, currentParent, isLeftStack.back(), varname, val, false);
      // We do this twice as we will get back here twice, once for left
      parent_stack.push_back(nodeCount);
      parent_stack.push_back(nodeCount);
    } 
    isLeftStack.push_back(isLeft);
  }

  // Prints a database error to the console
  void dbError(int res, string message) {
    if(res != SQLITE_OK && res != SQLITE_DONE) {
      cout << "DBERROR (" << to_string(res) << ") " << message << endl;
    }
  }

  // Initialiases the database
  void makeDB(string fileName) {
    int exit = 0;
    int status;

    // Check that the dump file can be opened/created.
    exit = sqlite3_open(fileName.c_str(), &db);

    if(exit) {
      std::cerr << "Could not open database!" << sqlite3_errmsg(db) << std::endl;
      return;
    } else {
      std::cout << "Opened database successfully!" << std::endl;
    }

    // Start the transaction
    sqlite3_exec(db, "BEGIN TRANSACTION", NULL, NULL, NULL);

    // Drop old tables so data is overwritten
    sqlite3_stmt* dropNodeStmt;
    string dropNodes = "drop table if exists Node";
    status = sqlite3_prepare_v2(db, dropNodes.c_str(), dropNodes.size(), &dropNodeStmt, NULL);
    dbError(status, "Prepare drop nodes");
    status = sqlite3_step(dropNodeStmt);
    dbError(status, "Execute drop nodes");

    sqlite3_stmt* dropDomainStmt;
    string dropDomains = "drop table if exists Domain";
    status = sqlite3_prepare_v2(db, dropDomains.c_str(), dropDomains.size(), &dropDomainStmt, NULL);
    dbError(status, "Prepare drop domains");
    status = sqlite3_step(dropDomainStmt);
    dbError(status, "Execute drop domains");

    // Create the Node table
    string createQuery =
        "CREATE TABLE IF NOT EXISTS Node (nodeId INTEGER, parentId INTEGER, "
        "isLeftChild INTEGER, branchingVariable TEXT, value INTEGER, isSolution INTEGER);";
    sqlite3_stmt* createStmt;
    status = sqlite3_prepare(db, createQuery.c_str(), createQuery.size(), &createStmt, NULL);
    dbError(status, "Prepare create Node Table");
    status = sqlite3_step(createStmt);
    dbError(status, "Execute create Node Table");

    // Create the Domain table
    createQuery = "CREATE TABLE IF NOT EXISTS Domain (domainId INTEGER, nodeId INTEGER references "
                  "Node(nodeId), name TEXT, lower INTEGER, upper INTEGER, index0 INTEGER, index1 "
                  "INTEGER, index2 INTEGER, index3 INTEGER, index4 INTEGER, index5 INTEGER, index6 "
                  "INTEGER, index7 INTEGER, index8 INTEGER, "
                  "index9 INTEGER);";

    status = sqlite3_prepare(db, createQuery.c_str(), createQuery.size(), &createStmt, NULL);
    dbError(status, "Prepare create Domain Table");
    status = sqlite3_step(createStmt);
    dbError(status, "Execute create Domain Table");

    // Prepare the insert node statement
    string insertNode =
        "INSERT INTO Node (nodeId, parentId, isLeftChild, branchingVariable, value, isSolution) "
        "VALUES (?, ?, ?, ? ,?, ?);";
    status = sqlite3_prepare_v2(db, insertNode.c_str(), insertNode.size(), &insertNodeStmt, NULL);
    dbError(status, "prepare insert node statement");

    // Prepare the insert domain statement
    string insertDomain =
        "INSERT INTO Domain (domainId, nodeId, name, lower, upper, index0, index1, "
        " index2, index3, index4, index5, index6, index7, index8, index9) VALUES (?, ?, ?, ?, ?, "
        "?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    status = sqlite3_prepare_v2(db, insertDomain.c_str(), insertDomain.size(), &insertDomainStmt, NULL);
    dbError(status, "prepare insert domain statement");
  }

  // Splits a string by a given delimeter
  vector<string> split(const string& s, char delim) {
    vector<string> result;
    stringstream ss(s);
    string item;

    while(getline(ss, item, delim)) {
      result.push_back(item);
    }
    return result;
  }

  // Writes a node record to the database
  void writeNodeToDb(long nodeId, long parentId, BOOL isLeft, string branchingVariableName, int branchingValue, bool isSolution) {

    int l = 0;
    int s = 0;

    if(isLeft) {
      l = 1;
    }
    if(isSolution) {
      s = 1;
    }

    int status = -1;

    // Bind parameters
    status = sqlite3_bind_int(insertNodeStmt, 1, nodeId);
    dbError(status, "Bind node ID");
    status = sqlite3_bind_int(insertNodeStmt, 2, parentId);
    dbError(status, "Bind Parent ID");
    status = sqlite3_bind_int(insertNodeStmt, 3, l);
    dbError(status, "Bind Left");
    status = sqlite3_bind_text(insertNodeStmt, 4, (branchingVariableName).c_str(), (branchingVariableName).size(), SQLITE_TRANSIENT);
    dbError(status, "Bind Var");
    status = sqlite3_bind_int(insertNodeStmt, 5, branchingValue);
    dbError(status, "Bind Val");
    status = sqlite3_bind_int(insertNodeStmt, 6, s);
    dbError(status, "Bind Solution");

    // Execute insert statement
    status = sqlite3_step(insertNodeStmt);
    dbError(status, "Execute insert node");

    // Reset the parameter bindings
    status = sqlite3_reset(insertNodeStmt);
    dbError(status, "Reset insert node");
  }

  // Writes all domains at the current node to the database
  void writeDomainsToDb(long long nodeId, const std::vector<AnyVarRef>& vars) {
    int status = -1;

    // List of domains already inserted, this is because there are often duplicates.
    vector<string> seen;

    for(int i = 0; i < vars.size(); i++) {

      // skip the domain if its a duplicate.
      if(std::find(seen.begin(), seen.end(), getBaseVarName(vars[i])) != seen.end()) {
        continue;
      }

      seen.push_back(getBaseVarName(vars[i]));

      // Bind parameters to the insert statement
      status = sqlite3_bind_int(insertDomainStmt, 1, i);
      dbError(status, "Bind reference to domain id");
      status = sqlite3_bind_int(insertDomainStmt, 2, nodeId);
      dbError(status, "Bind reference to node id");
      status = sqlite3_bind_text(insertDomainStmt, 3, getBaseVarName(vars[i]).c_str(), getBaseVarName(vars[i]).size(), SQLITE_TRANSIENT);
      dbError(status, "Bind Domain Name");
      status = sqlite3_bind_int(insertDomainStmt, 4, vars[i].getMin());
      dbError(status, "Bind Lower");
      status = sqlite3_bind_int(insertDomainStmt, 5, vars[i].getMax());
      dbError(status, "Bind Upper");

      string s = getBaseVarName(vars[i]);

      // Check to see if the indexes for this variable have already been generated
      std::unordered_map<string, vector<int>>::iterator it = indexMap.find(s);

      // if not then the indexes must be generated
      if(it == indexMap.end()) {

        vector<int> indexList;
        indexMap[s] = indexList;

        // Split the variable name by underscore
        vector<string> v = split(s, '_');

        // For each item check if its a number
        for(auto token : v) {

          try {
            int num = stoi(token);

            // If its a number then add it to the map
            indexMap[s].push_back(num);

          } catch(std::invalid_argument& e) {}
        }
      }

      int indexCount = 5;

      // Bind all the index parametes
      for(auto index : indexMap[s]) {
        indexCount++;
        status = sqlite3_bind_int(insertDomainStmt, indexCount, index);
        dbError(status, "Bind Index" + to_string(indexCount));
      }

      // Execute the insert domain statement
      status = sqlite3_step(insertDomainStmt);
      dbError(status, "Execute insert domain");

      // Reset the statement so it can be used again
      status = sqlite3_reset(insertDomainStmt);
      dbError(status, "Reset insert domain");

      // Reset the bindings because they wont always be overwritten by the next domain
      status = sqlite3_clear_bindings(insertDomainStmt);
      dbError(status, "clear domain bindings");
    }
  }

  // Closes the database
  void closeDB() {

    // Create indexes
    sqlite3_stmt* nodeIdDomainsIndexStmt;
    sqlite3_stmt* parentIdNodeIndexStmt;
    sqlite3_stmt* nodeIdNodeIndexStmt;

    string nodeIdDomainsIndex = "CREATE INDEX nodeIdIndex ON Domain (nodeId);";
    string parentIdNodeIndex = "CREATE INDEX parent ON Node (parentId);";
    string nodeIdNodeIndex = "CREATE INDEX node ON Node (nodeId);";

    int status = sqlite3_prepare_v2(db, nodeIdDomainsIndex.c_str(), nodeIdDomainsIndex.size(), &nodeIdDomainsIndexStmt, NULL);
    status = sqlite3_step(nodeIdDomainsIndexStmt);
    
    status = sqlite3_prepare_v2(db, parentIdNodeIndex.c_str(), parentIdNodeIndex.size(), &parentIdNodeIndexStmt, NULL);
    status = sqlite3_step(parentIdNodeIndexStmt);

    status = sqlite3_prepare_v2(db, nodeIdNodeIndex.c_str(), nodeIdNodeIndex.size(), &nodeIdNodeIndexStmt, NULL);
    status = sqlite3_step(nodeIdNodeIndexStmt);

    char* error = nullptr;

    // End the transaction
    status = sqlite3_exec(db, "END TRANSACTION", NULL, NULL, &error);

    dbError(status, "Ending the transaction");

    sqlite3_finalize(insertNodeStmt);
    sqlite3_finalize(insertDomainStmt);
    sqlite3_close(db);
  }

  // Destructor
  ~DumpTreeSQL() {
    closeDB();
  }
};

std::shared_ptr<SearchDumper> makeDumpTreeSQL(string fileName) {
  return std::shared_ptr<SearchDumper>(new DumpTreeSQL(fileName));
}
