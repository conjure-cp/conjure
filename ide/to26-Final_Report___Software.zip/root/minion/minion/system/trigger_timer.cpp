/*
* Minion http://minion.sourceforge.net
* Copyright (C) 2006-09
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
* USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <ostream>
#include <atomic>

using namespace std;

std::atomic<bool>* trig;
std::atomic<bool>* ctrl_c_press;

bool check_double_ctrlc;

#include <stdio.h>

#ifdef _WIN32

#define _WIN32_WINNT 0x0500
#include <windows.h>

void CALLBACK TimerProc(void*, BOOLEAN) {
  *trig = true;
}

void CALLBACK ReallyStop(void*, BOOLEAN) {
  exit(1);
}

void activate_trigger(std::atomic<bool>* b, bool timeout_active, int timeout, bool CPU_time) {
  if(CPU_time)
    cerr << "CPU-time timing not available on windows, falling back on clock" << endl;

  trig = b;
  *trig = false;

  HANDLE m_timerHandle;

  if(timeout_active) {
    if(timeout <= 0)
      *trig = true;
    BOOL success = ::CreateTimerQueueTimer(&m_timerHandle, NULL, TimerProc, NULL, timeout * 1000, 0,
                                           WT_EXECUTEINTIMERTHREAD);
  }
}

void install_ctrlc_trigger(std::atomic<bool>*) { /* Not implemented on windows */
}

#else
#include <sys/types.h>
#include <sys/resource.h>
#include <signal.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>

void trigger_function(int /* signum */) {
  *trig = true;
}

void activate_trigger(std::atomic<bool>* b, bool timeout_active, int timeout,
                      bool CPU_time) // CPU_time = false -> real time
{
  // We still set these, as they are how 'ctrlc' checks if we have got started
  // properly or not.
  trig = b;
  *trig = false;

  signal(SIGXCPU, trigger_function);
  signal(SIGALRM, trigger_function);
  if(timeout_active) {
    if(timeout <= 0)
      *trig = true;
    if(CPU_time) {
      rlimit lim;
      lim.rlim_cur = timeout;
      lim.rlim_max = timeout + 5;
      setrlimit(RLIMIT_CPU, &lim);
    } else
      alarm(timeout);
  }
}

void ctrlc_function(int /* signum */) {
  if(check_double_ctrlc) {
    cerr << "Ctrl+C pressed twice. Exiting immediately." << endl;
    exit(1);
  }

  if(trig == NULL) {
    cerr << "Search has not started. Exiting immediately." << endl;
    exit(1);
  }

  check_double_ctrlc = true;

  cerr << getpid() << ": Ctrl+C pressed. Exiting." << std::endl;
  // This is the quickest way to get things to stop.
  *trig = true;
  *ctrl_c_press = true;
}

void install_ctrlc_trigger(std::atomic<bool>* ctrl_c_press_) {
  check_double_ctrlc = false;
  ctrl_c_press = ctrl_c_press_;
  signal(SIGINT, ctrlc_function);
}
#endif
